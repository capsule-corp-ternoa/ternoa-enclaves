subxt metadata --url wss://dev-0.ternoa.network:443 > ternoa_dev0.scale 2>/dev/null
subxt metadata --url wss://dev-1.ternoa.network:443 > ternoa_dev1.scale 2>/dev/null
subxt metadata --url wss://alphanet.ternoa.com:443 > ternoa_alphanet.scale 2>/dev/null
subxt metadata --url wss://mainnet.ternoa.network:443 > ternoa_mainnet.scale 2>/dev/null
