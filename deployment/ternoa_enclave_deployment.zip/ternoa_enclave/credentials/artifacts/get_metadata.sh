subxt metadata --url wss://alphanet.ternoa.com:443 > ternoa_alphanet.scale
subxt metadata --url wss://mainnet.ternoa.network:443 > ternoa_mainnet.scale
subxt metadata --url wss://dev-1.ternoa.network:443 > ternoa_dev1.scale
subxt metadata --url wss://dev-0.ternoa.network:443 > ternoa_dev0.scale
